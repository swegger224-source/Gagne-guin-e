Gagne Guinée - projet Android avec AdMob

ID application AdMob:
ca-app-pub-3912034289758525~4865706999

ID bloc publicitaire:
ca-app-pub-3912034289758525/1542198796

Le projet utilise un bandeau AdMob en bas de l'écran.
